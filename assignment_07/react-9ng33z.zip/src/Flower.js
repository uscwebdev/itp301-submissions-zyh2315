import React, { useState } from 'react';

export default function Flower(props) {
  const [count, setCount] = useState(0);

  const handlePlusClick = () => {
    setCount(count + 1);
  };

  const handleMinusClick = () => {
    if (count > 0) {
      setCount(count - 1);
    }
  };
  return (
    <div calssName="flower">
      <img src={props.src} alt={'Picture of ' + props.name} />
      <h2>{props.name}</h2>
      <h3>${props.price}</h3>
      <button onClick={handleMinusClick}>-</button>
      <span>{count}</span>
      <button onClick={handlePlusClick}>+</button>
    </div>
  );
}
