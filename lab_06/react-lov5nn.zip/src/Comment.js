import React from 'react';

export default function Comment(props){
  return(
    <div className='comments'>
        <img
        src={props.src}
        alt={props.caption + ' Profile Picture'}
        className="img-fluid"
        />
        <p className="name">{props.caption}</p>
        <p className="date">{props.date}</p>
        <p className="comment_content">{props.content}</p>

      </div>
  )
}