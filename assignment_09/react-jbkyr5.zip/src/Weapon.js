import React from 'react';
import { createRoot } from 'react-dom/client';
import Navbar from './Navbar';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Weapon from './Weapon';
import Heros from './Heros';
import Weapons from './Weapons';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <Router>
      <div className="container">
        <h1 className="mainTopic">NARAKA: BLADEPOINT</h1>
        <div className="navigation">
          <Navbar />
        </div>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Weapons" element={<Weapons />} />
          <Route path="/Heros" element={<Heros />} />
        </Routes>
      </div>
      <Weapon
        src="img/1.jpg"
        caption="Longsword"
        normal="Normal attack text"
        special="Special attack text"
        combination="Combination attack text"
      />
    </Router>
  </React.StrictMode>
);
