import React from 'react';

export default function Hero(props) {
  return (
    <div className="hero">
      <img src={props.src} alt={props.caption + ' Profile Picture'} />
      <p className="name">{props.caption}</p>
      <p className="ability">{props.ability}</p>
      <p className="story">{props.story}</p>
    </div>
  );
}
