import React from 'react';
import { createRoot } from 'react-dom/client';
import Navbar from './Navbar';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Weapon from './Weapon';
import Heros from './Heros';
import Weapons from './Weapons';
import Hero from './Hero';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <Router>
      <div className="container">
        <h1 className="mainTopic">NARAKA: BLADEPOINT</h1>
        <div className="navigation">
          <Navbar />
        </div>
        <Routes>
          <Route path="/Home" element={<Home />} />
          <Route path="/Weapons" element={<Weapons />} />
          <Route path="/Heros" element={<Heros />} />
        </Routes>
      </div>
    </Router>
  </React.StrictMode>
);
