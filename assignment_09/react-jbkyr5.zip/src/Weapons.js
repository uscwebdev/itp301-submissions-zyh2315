import React from 'react';

export default function Weapon(props) {
  return (
    <div className="weapon">
      <img src={props.src} alt={props.caption + ' Profile Picture'} />
      <p className="name">{props.caption}</p>
      <p className="normal">{props.normal}</p>
      <p className="special">{props.special}</p>
      <p className="combination">{props.combination}</p>
    </div>
  );
}
