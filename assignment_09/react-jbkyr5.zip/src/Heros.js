import React from 'react';

function Heros() {
  return <div></div>;
}

export default Heros;
