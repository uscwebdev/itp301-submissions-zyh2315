import React from 'react';
import Hero from './Hero';

export default function Heros() {
  const heroList = [
    {
      src: 'https://naraka.wiki/characters/full/kurumi.webp',
      caption: 'Kurumi',
      skill: 'Heal, support',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/SPMhPK8teUc',
    },

    {
      src: 'https://naraka.wiki/characters/full/valda-cui.webp',
      caption: 'Valda Cui',
      skill: 'Attack, ontrol',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/vyChYFjXwR8',
    },

    {
      src: 'https://naraka.wiki/characters/full/viper-ning.webp',
      caption: 'Viper Ning',
      skill: 'Control',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/ffUUGpeCl2o',
    },

    {
      src: 'https://naraka.wiki/characters/full/justina-gu.webp',
      caption: 'Justina Gu',
      skill: 'Control, Heal',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/LFFuHmum33A',
    },

    {
      src: 'https://naraka.wiki/characters/full/matari.webp',
      caption: 'Matari',
      skill: 'Attack',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/ivRbw4TYm6k',
    },

    {
      src: 'https://naraka.wiki/characters/full/takeda-nobutada.webp',
      caption: 'Takeda Nobutada',
      skill: 'Attack, heal',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/-HdCWeQJH2A',
    },

    {
      src: 'https://naraka.wiki/characters/full/tarka-ji.webp',
      caption: 'Tarka Ji',
      skill: 'Attack',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/J0tvoRYrS6A',
    },

    {
      src: 'https://naraka.wiki/characters/full/tessa.png',
      caption: 'Tessa',
      skill: 'Control, heal',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/hDnSPSEcniA',
    },

    {
      src: 'https://naraka.wiki/characters/full/tianhai.webp',
      caption: 'Tianhai',
      skill: 'Control, attack, heal',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/XrmOuh7hCPM',
    },

    {
      src: 'https://naraka.wiki/characters/full/yueshan.webp',
      caption: 'Yueshan',
      skill: 'Attack, control',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/8TncTV3K2mQ',
    },

    {
      src: 'https://naraka.wiki/characters/full/wuchen.webp',
      caption: 'Wuchen',
      skill: 'Heal, support',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/PF-OS9qQlCU',
    },
  ];

  return (
    <div className="heros-gallery">
      {heroList.map((hero, index) => (
        <Hero
          key={index}
          src={hero.src}
          caption={hero.caption}
          skill={hero.skill}
          skillLink={hero.skillLink}
          guide={hero.guide}
          guideLink={hero.guideLink}
        />
      ))}
    </div>
  );
}
