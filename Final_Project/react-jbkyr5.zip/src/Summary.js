import React, { useState } from 'react';

export default function Summary() {
  return (
    <div>
      <h2>Project Summary</h2>
      <p>
        This website is used to introduce a game named "Naraka: Bladepoint" to
        the audiences. There are basic information about the weapons and heros
        of the game. Besides, there is a form that can collect audiances'
        information to find a teammate that they can play together.
      </p>
      <p>
        Navbar: At the top of the page, there is the navigation bar. This bar
        includes links to different pages of the website. Links include:
      </p>
      <ul>
        <li>Home: Returns you to the homepage. </li>
        <li>
          Weapons: Takes you to a page detailing different weapons (assuming
          this is relevant to the website's content).
        </li>
        <li>
          Heros: Leads to a page with information about different heroes or
          characters.
        </li>
        <li>
          More: Opens a page with additional options or information, like a form
          for user input.
        </li>
      </ul>
      <p>
        Interacting with Forms Filling Out Forms: On certain pages, like the
        "More" page, you might find a form to fill out. This form can include:
      </p>
      <ul>
        <li>
          Text Inputs: For entering your name, email, etc. Click on the input
          field and start typing.
        </li>
        <li>
          Radio Buttons: For choosing one option out of several, such as your
          preferred type of game.
        </li>
        <li>Click on your choice.</li>
        <li>
          {' '}
          Checkboxes: For selecting multiple options, like the time periods when
          you usually play. You can check multiple boxes.
        </li>
        <li>
          Submitting Forms: After filling out the form: Click the "Submit"
          button. If all required fields are filled correctly, you'll see a
          confirmation message, like "Submit Successfully." If there are errors
          or missing information, an alert will notify you of what needs to be
          corrected.
        </li>
      </ul>
      <p>
        For the extras, I applied react-router-dom to make sure the website can
        have different pages that linked together. Also, I aplied DOM storage to
        save and reload the data from the form that the users filled without
        clicking submit button.
      </p>
    </div>
  );
}
