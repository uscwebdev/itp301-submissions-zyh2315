import React from 'react';
import './Home.css';

function Home() {
  return (
    <div>
      <h2>Introduction</h2>
      <p>
        Naraka: Bladepoint is a free-to-play action battle royale game developed
        by 24 Entertainment and published by NetEase Games Montreal. It is a
        game where up to 60 players fight each other to be the last one
        standing. The game incorporates martial arts-inspired melee combat and
        features a rock-paper-scissors combat system. There are vast arsenals of
        melee and ranged weapons to choose from, as well as a grappling hook
        that can be used for both combat and traversal. In addition, each hero
        has unique skills and talents, allowing for customization to suit your
        play style.
      </p>
      <p>
        New to Morus Isle? This handy guide provides some quick tips and
        resources to help you get up to speed as you hack and slash your way to
        victory. When you start NARAKA: BLADEPOINT you will have to complete
        both the basic and advanced tutorials which introduces you to the main
        mechanics, lore, and tactics you will use throughout your matches.
        Completing these gives you some initial in-game rewards and you can
        always return to them if you need a refresher.
      </p>
      <h2>Photo Gallery</h2>
      <div className="photoGallery">
        <p>Beautiful Views</p>
        <img
          src="https://w.wallhaven.cc/full/q2/wallhaven-q2llkd.jpg"
          alt="Morus Isle - 1"
        />
        <img
          src="https://w.wallhaven.cc/full/z8/wallhaven-z8557g.jpg"
          alt="Morus Isle - 2"
        />
        <img
          src="https://w.wallhaven.cc/full/e7/wallhaven-e7wwlk.jpg"
          alt="Morus Isle - 3"
        />
        <img
          src="https://w.wallhaven.cc/full/x8/wallhaven-x8pjwo.jpg"
          alt="Morus Isle - 4"
        />
      </div>
      <div className="esport">
        <h2>Esports</h2>
        <a href="https://www.narakathegame.com/2022championship/#/">J Cup</a>
      </div>
    </div>
  );
}

export default Home;
