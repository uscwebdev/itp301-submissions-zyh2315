import React from 'react';

export default function Weapon({
  src,
  caption,
  skill,
  skillLink,
  guide,
  guideLink,
}) {
  return (
    <div className="weapon">
      <img src={src} alt={caption} />
      <h3>{caption}</h3>
      <p>
        Skill:{' '}
        <a href={skillLink} target="_blank" rel="noopener noreferrer">
          {skill}
        </a>
      </p>
      <p>
        <a href={guideLink} target="_blank" rel="noopener noreferrer">
          {guide}
        </a>
      </p>
    </div>
  );
}
