import React from 'react';
import Weapon from './Weapon';

export default function Weapons() {
  const weaponsList = [
    {
      src: 'https://www.narakathegame.com/pc/zt/20230615144952/assets/11-47289_6b46492b.png',
      caption: 'Longsword',
      skill: 'Horizontal Energy & Vertical Energy',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/J-pI9C5RCEA',
    },

    {
      src: 'https://www.narakathegame.com/pc/zt/20230615144952/assets/11-016301_6d173952.png',
      caption: 'Katana',
      skill: 'Horizontal Energy & Vertical Energy',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/HG_nYNH7TIM',
    },

    {
      src: 'https://www.narakathegame.com/pc/zt/20230615144952/assets/11-023568_b9dbbefa.png',
      caption: 'Greatesword',
      skill: 'Horizontal Energy & Vertical Energy',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/Mvh70h8KwBg',
    },

    {
      src: 'https://www.narakathegame.com/pc/zt/20230615144952/assets/11-63518_ab9ce9a5.png',
      caption: 'Spare',
      skill: 'Horizontal Energy & Vertical Energy',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/TuQRyukI9TA',
    },

    {
      src: 'https://www.narakathegame.com/pc/zt/20230615144952/assets/527-1165_95ec53d1.png',
      caption: 'Fan',
      skill: 'Horizontal Energy & Vertical Energy',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/a1YU9ejP8rs',
    },

    {
      src: 'https://www.narakathegame.com/pc/zt/20230615144952/assets/11-030818_548946d0.png',
      caption: 'Nunchuck',
      skill: 'Horizontal Energy & Vertical Energy',
      guide: 'click here to view the guide',
      guideLink: 'https://youtu.be/5uApC0ozfIM',
    },
  ];

  return (
    <div className="weapons-gallery">
      {weaponsList.map((weapon, index) => (
        <Weapon
          key={index}
          src={weapon.src}
          caption={weapon.caption}
          skill={weapon.skill}
          skillLink={weapon.skillLink}
          guide={weapon.guide}
          guideLink={weapon.guideLink}
        />
      ))}
    </div>
  );
}
