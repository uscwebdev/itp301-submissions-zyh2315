import React from 'react';
import './MoreForm.css';

function Mores() {
  return (
    <div>
      <MoreForm />
    </div>
  );
}

export default Mores;
