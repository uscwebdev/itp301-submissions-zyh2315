import React, { useState } from 'react';
import React, { useState, useEffect } from 'react';
import './MoreForm.css';

function MoreForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    gameType: '',
    playTimes: [],
  });
  const [errors, setErrors] = useState({});
  const [submitStatus, setSubmitStatus] = useState('');

  const validate = () => {
    let tempErrors = {};
    let isValid = true;

    if (!formData.name) {
      tempErrors.name = 'Name is required';
      isValid = false;
    }
    if (!formData.email) {
      tempErrors.email = 'Email is required';
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      tempErrors.email = 'Email is invalid';
      isValid = false;
    }
    if (!formData.gameType) {
      tempErrors.gameType = 'Game type selection is required';
      isValid = false;
    }
    if (formData.playTimes.length === 0) {
      tempErrors.playTimes = 'Please select at least one time period';
      isValid = false;
    }

    setErrors(tempErrors);
    return isValid;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSubmitStatus('');

    if (type === 'checkbox') {
      setFormData({
        ...formData,
        playTimes: checked
          ? [...formData.playTimes, value]
          : formData.playTimes.filter((t) => t !== value),
      });
    } else {
      setFormData({ ...formData, [name]: value });
    }
    setErrors({ ...errors, [name]: '' });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log('Form data submitted:', formData);
      localStorage.setItem('userFormData', JSON.stringify(formData));
      alert('Submit Successfully.');

      setFormData({
        name: '',
        email: '',
        gameType: '',
        playTimes: [],
      });

      setSubmitStatus('');
      setErrors({});
    } else {
      alert('Submit Unsuccessful.');
      setSubmitStatus('Submit Unsuccessful.'); 
    }
  };

  useEffect(() => {
    const storedData = JSON.parse(localStorage.getItem('userFormData'));
    if (storedData) {
      setFormData(storedData);
    }
  }, []);

  return (
    <div>
      <h2>Are you looking for someone to play together?</h2>
      <form onSubmit={handleSubmit}>
        <table>
          <tbody>
            <tr>
              <td>Name:</td>
              <td>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                />
                {errors.name && <p>{errors.name}</p>}
              </td>
            </tr>
            <tr>
              <td>Email:</td>
              <td>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
                {errors.email && <p>{errors.email}</p>}
              </td>
            </tr>
            <tr>
              <td>Which type of game do you prefer?</td>
              <td>
                <label>
                  <input
                    type="radio"
                    name="gameType"
                    value="Solo"
                    checked={formData.gameType === 'Solo'}
                    onChange={handleChange}
                  />{' '}
                  Solo
                </label>
                <label>
                  <input
                    type="radio"
                    name="gameType"
                    value="Duo"
                    checked={formData.gameType === 'Duo'}
                    onChange={handleChange}
                  />{' '}
                  Duo
                </label>
                <label>
                  <input
                    type="radio"
                    name="gameType"
                    value="Tri"
                    checked={formData.gameType === 'Tri'}
                    onChange={handleChange}
                  />{' '}
                  Tri
                </label>
                {errors.gameType && <p>{errors.gameType}</p>}
              </td>
            </tr>
            <tr>
              <td>What time periods do you usually play NARAKA?</td>
              <td>
                <label>
                  <input
                    type="checkbox"
                    name="playTimes"
                    value="Morning"
                    checked={formData.playTimes.includes('Morning')}
                    onChange={handleChange}
                  />{' '}
                  Morning
                </label>
                <label>
                  <input
                    type="checkbox"
                    name="playTimes"
                    value="Afternoon"
                    checked={formData.playTimes.includes('Afternoon')}
                    onChange={handleChange}
                  />{' '}
                  Afternoon
                </label>
                <label>
                  <input
                    type="checkbox"
                    name="playTimes"
                    value="Night"
                    checked={formData.playTimes.includes('Night')}
                    onChange={handleChange}
                  />{' '}
                  Night
                </label>
                <label>
                  <input
                    type="checkbox"
                    name="playTimes"
                    value="Midnight"
                    checked={formData.playTimes.includes('Midnight')}
                    onChange={handleChange}
                  />{' '}
                  Midnight
                </label>
                {errors.playTimes && <p>{errors.playTimes}</p>}
              </td>
            </tr>
          </tbody>
        </table>
        <button type="submit">Submit</button>
        <p>{submitStatus}</p>
      </form>
    </div>
  );
}

export default MoreForm;
