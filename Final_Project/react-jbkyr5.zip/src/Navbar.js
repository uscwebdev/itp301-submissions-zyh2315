import React from 'react';
import './Navbar.css';

function Navbar() {
  return (
    <nav>
      <ul>
        <li>
          <a href="/Home">Home</a>
        </li>
        <li>
          <a href="/Weapons">Weapons</a>
        </li>
        <li>
          <a href="/Heros">Heros</a>
        </li>
        <li>
          <a href="/Mores">More</a>
        </li>
        <li>
          <a href="/Summary">Summary</a>
        </li>
      </ul>
    </nav>
  );
}

export default Navbar;
