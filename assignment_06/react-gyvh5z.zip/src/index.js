import React from 'react';
import { createRoot } from 'react-dom/client';
import Flower from './Flower.js';
import './html.css';

const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="body">
      <h1>Flower Online Market</h1>
      <div id="content">
        <Flower
          src="https://m.media-amazon.com/images/I/51aFz6ACxrL.__AC_SX300_SY300_QL70_FMwebp_.jpg"
          name="rose"
          price="10"
        />

        <Flower
          src="https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/hydrangea-lets-dance-sky-view-1.jpg"
          name="macrophylla"
          price="20"
        />

        <Flower
          src="https://www.wholesalenurseryco.com/cdn/shop/files/LilyoftheValley__1.jpg?v=1691509910&width=493"
          name="lily of the valley"
          price="50"
        />

        <Flower
          name="jasmine"
          src="https://m.media-amazon.com/images/I/51lWYfCYjKL.__AC_SY300_SX300_QL70_FMwebp_.jpg"
          price="25"
        />
        {/*
      <div class="flower">
        <img
          id="rose"
          src="https://m.media-amazon.com/images/I/51aFz6ACxrL.__AC_SX300_SY300_QL70_FMwebp_.jpg"
          alt="Picture of white rose"
        />
        <h2>White Rose</h2>
        <h3>$10</h3>
      </div>

      <div class="flower">
        <img
          id="macrophylla"
          src="https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/hydrangea-lets-dance-sky-view-1.jpg"
          alt="Picture of hydrangea macrophylla"
        />
        <h2>Hydrangea Macrophylla</h2>
        <h3>$20</h3>
      </div>

      <div class="flower">
        <img
          id="lily"
          src="https://www.wholesalenurseryco.com/cdn/shop/files/LilyoftheValley__1.jpg?v=1691509910&width=493"
          alt="Picture of lily of the valley"
        />
        <h2>Lily of the Valley</h2>
        <h3>$50</h3>
      </div>

      <div class="flower">
        <img
          id="jasmine"
          src="https://m.media-amazon.com/images/I/51lWYfCYjKL.__AC_SY300_SX300_QL70_FMwebp_.jpg"
          alt="Picture of jasmin"
        />
        <h2>Jasmine</h2>
        <h3>$25</h3>
      </div> */}

        <div id="cart">
          <h4>Your Cart</h4>
          <h4>
            Subtotal: $ <span id="total">0</span>
          </h4>
        </div>
      </div>
    </div>
  </React.StrictMode>
);
