import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import Flower from './Flower.js';
import './html.css';

const App = () => {
  const [subtotal, setSubtotal] = useState(0);

  const increaseSubtotal = (price) => {
    const numericPrice = parseFloat(price);
    setSubtotal(subtotal + numericPrice);
  };

  const decreaseSubtotal = (price) => {
    const numericPrice = parseFloat(price);
    if (subtotal >= numericPrice) {
      setSubtotal(subtotal - numericPrice);
    }
  };

  return (
    <React.StrictMode>
      <div id="body">
        <h1>Flower Online Market</h1>
        <div id="content">
          <Flower
            src="https://m.media-amazon.com/images/I/51aFz6ACxrL.__AC_SX300_SY300_QL70_FMwebp_.jpg"
            name="rose"
            price="10"
            increaseSubtotal={increaseSubtotal}
            decreaseSubtotal={decreaseSubtotal}
          />

          <Flower
            src="https://www.provenwinners.com/sites/provenwinners.com/files/imagecache/500x500/ifa_upload/hydrangea-lets-dance-sky-view-1.jpg"
            name="macrophylla"
            price="20"
            increaseSubtotal={increaseSubtotal}
            decreaseSubtotal={decreaseSubtotal}
          />

          <Flower
            src="https://www.wholesalenurseryco.com/cdn/shop/files/LilyoftheValley__1.jpg?v=1691509910&width=493"
            name="lily of the valley"
            price="50"
            increaseSubtotal={increaseSubtotal}
            decreaseSubtotal={decreaseSubtotal}
          />

          <Flower
            name="jasmine"
            src="https://m.media-amazon.com/images/I/51lWYfCYjKL.__AC_SY300_SX300_QL70_FMwebp_.jpg"
            price="25"
            increaseSubtotal={increaseSubtotal}
            decreaseSubtotal={decreaseSubtotal}
          />

          <div id="cart">
            <h4>Your Cart</h4>
            <h4>Subtotal: $ {subtotal.toFixed(2)}</h4>
          </div>
        </div>
      </div>
    </React.StrictMode>
  );
};

const root = createRoot(document.querySelector('#root'));
root.render(<App />);
