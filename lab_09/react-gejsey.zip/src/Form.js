import React from 'react';
import React, { useState } from 'react';

export default function Form() {
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comments, setComments] = useState('');
  const [termsAndConditions, setTermsAndConditions] = useState(false);

  const handleChange = (event) => {
    const { id, value, type, checked } = event.target;
    switch (id) {
      case 'full-name':
        setFullName(value);
        break;
      case 'password':
        setPassword(value);
        break;
      case 'password-confirm':
        setConfirmPassword(value);
        break;
      case 'email':
        setEmail(value);
        break;
      case 'phone':
        setPhone(value);
        break;
      case 'comment':
        setComments(value);
        break;
      case 'terms':
        setTermsAndConditions(checked);
        break;
      default:
        break;
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    let errors = [];

    if (!fullName.trim() || !/\s/.test(fullName)) {
      errors.push('Name cannot be empty. You must provide a full name.');
    }
    if (
      !password ||
      password.length < 5 ||
      !/[A-Z]/.test(password) ||
      !/[a-z]/.test(password)
    ) {
      errors.push(
        'Password must contain at least 5 characters and include both uppercase and lowercase characters.'
      );
    }
    if (password !== confirmPassword) {
      errors.push('Passwords do not match.');
    }
    if (!email.trim() && !phone.trim()) {
      errors.push('You must provide either email or phone.');
    }
    if (comments.length > 100) {
      errors.push('Comments cannot exceed 100 characters.');
    }
    if (!termsAndConditions) {
      errors.push('You must accept Terms & Conditions.');
    }

    if (errors.length > 0) {
      alert(errors.join('\n'));
    } else {
      alert('Registration Successful');
    }
  };

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  value={fullName}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  value={password}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  value={confirmPassword}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      value={email}
                      onChange={handleChange}
                    />
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      value={phone}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  value={comments}
                  onChange={handleChange}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {comments.length} / 100
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    checked={termsAndConditions}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
