import React from 'react';
import { createRoot } from 'react-dom/client';
import Images from './Image.js';
import './html.css';

const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <Images />
  </React.StrictMode>
);
