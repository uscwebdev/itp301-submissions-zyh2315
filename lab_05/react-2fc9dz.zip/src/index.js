import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Yinghui Zhang</h1>
    <h3>
      <a class="link" href="yinghuiz@usc.edu">
        yinghuiz@usc.edu
      </a>
    </h3>
    <p id="fav_color">Favorite Color</p>
    <p id="fav_website">
      <a class="link" href="https://www.bilibili.com/">
        Favorite Website
      </a>
    </p>
    <img
      id="fav_pic"
      src="https://github.com/uscwebdev/itp301-submissions-zyh2315/blob/gh-pages/assignment_01/img3.jpg?raw=true"
      alt="favorite picture"
    />
    <div id="class">
      <h2>Class</h2>
      <ul>
        <li>ITP 301</li>
        <li>DSCI 351</li>
        <li>ECON 305</li>
        <li>ECON 318</li>
        <li>ECON 457</li>
      </ul>
    </div>
  </React.StrictMode>
);
